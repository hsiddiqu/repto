Inheritance Excercise
